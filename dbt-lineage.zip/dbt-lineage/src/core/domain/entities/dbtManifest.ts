import { IManifestConfig } from "../interfaces/IManifest";

export class Manifest implements IManifestConfig {
    private static instance: Manifest;
    public manifest_path: string;

    private constructor() {
        this.manifest_path = '';
    }

    public setManifestPath(manifest_path: string) {
        this.manifest_path = manifest_path;
    }

    public getManifestPath() {
        return this.manifest_path;
    }

    public static getInstance(): Manifest {
        if(!Manifest.instance) {
            Manifest.instance = new Manifest();
        }

        return Manifest.instance;
    }
}