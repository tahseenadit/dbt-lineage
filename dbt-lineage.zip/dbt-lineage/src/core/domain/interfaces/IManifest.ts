export interface IManifestConfig {
    readonly manifest_path: string; // The property can only be set once (typically during initialization/construction) and cannot be modified afterwards. It helps to enforce immutability in this domain model
}