import { window, workspace} from 'vscode';
import * as path from 'path';

import { Manifest } from '../domain/entities/dbtManifest'

export class GetManifestPath {
    private static instance: GetManifestPath;
    private manifest!: Manifest; // declare the manifest property

    private constructor(){
        this.setManifestPath();
    }

    private setManifestPath() {
        const workspaceFolders = workspace.workspaceFolders;
        if(!workspaceFolders) {
            throw new Error('No workspace folder found!');
        }
        const active_terminal = window.activeTerminal; // Get the current active terminal
        const cwd = active_terminal?.shellIntegration?.cwd; // Get the integrated shell and then get the current working directory
        const manifest_path = path.join(cwd?.fsPath || workspaceFolders[0].uri.fsPath, 'target', 'manifest.json');
        this.manifest = Manifest.getInstance();
        this.manifest.setManifestPath(manifest_path); // Assign to the property

    }

    public getManifestPath() {
        this.setManifestPath();
        return this.manifest.getManifestPath();
    }

    public static getInstance(): GetManifestPath {
        if(!GetManifestPath.instance) {
            GetManifestPath.instance = new GetManifestPath();
        }

        return GetManifestPath.instance;
    }
}