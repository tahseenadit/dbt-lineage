// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';

import { GetManifestPath } from './core/useCases/GetManifestPath'

// This method is called when your extension is activated
// Your extension is activated the very first time the command is executed
export function activate(context: vscode.ExtensionContext) {

	// Use the console to output diagnostic information (console.log) and errors (console.error)
	// This line of code will only be executed once when your extension is activated
	console.log('Congratulations, your extension "dbt-lineage" is now active!');

	// The command has been defined in the package.json file
	// Now provide the implementation of the command with registerCommand
	// The commandId parameter must match the command field in package.json
	const disposable = vscode.commands.registerCommand('dbt-lineage.helloWorld', async () => { // Make the command async to properly handle the file operation
		try {
			vscode.window.onDidChangeTerminalShellIntegration(() => {
				// Try to find manifest.json in the target/compiled directory
				const get_manifest_path = GetManifestPath.getInstance();
				get_manifest_path.getManifestPath();
			});

			const get_manifest_path = GetManifestPath.getInstance();
			const manifest_path = get_manifest_path.getManifestPath();

			if (!fs.existsSync(manifest_path)) {
				throw new Error('manifest.json not found. Please run dbt compile first.');
			}

			// Read and parse the manifest file
			const manifestContent = fs.readFileSync(manifest_path, 'utf8');
			const manifest = JSON.parse(manifestContent);

			// Extract child and parent relationships
			const nodes = manifest.nodes || {};
			const childParentMap = new Map<string, string[]>();
			const parentChildMap = new Map<string, string[]>();

			// Build the relationship maps
			for(const [nodeName, nodeData] of Object.entries(nodes)) {
				//console.log(nodeName);
				const parents = (nodeData as any).depends_on?.nodes || [];
				/*
				const parents = (nodeData as any).depends_on?.nodes || [];
				childParentMap.set(nodeName, parents);

				parents.forEach()*/
			}


		} catch (error: any) {
			if(error) {
				vscode.window.showErrorMessage(`Error: ${error.message}`);
			}
		}
	});

	context.subscriptions.push(disposable);
}

// This method is called when your extension is deactivated
export function deactivate() {}
